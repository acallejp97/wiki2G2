Hello,

Thank for downloading BENZA.

NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated. 


Paypal account for donation : https://www.paypal.me/mlkwsn

Link to purchase full version and commercial license:https://creativemarket.com/mlkwsn999/2183273-Benza


Please visit our store for more great fonts : https://creativemarket.com/mlkwsn999




If there is a problem, question, or anything about my fonts, please sent an email to

mlkwsn999@gmail.com



How to Enable OpenType Features in Word, 
Photoshop and Illustrator

https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/

Thanks,

MLKWSN Studios