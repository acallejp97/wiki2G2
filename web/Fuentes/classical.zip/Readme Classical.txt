Hello,

Thank for downloading Clasical



NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated. 


Paypal account for donation : https://www.paypal.me/mlkwsn

Link to purchase full version and commercial license:

Please visit our store for more great fonts : https://creativemarket.com/mlkwsn999/2899935-Classical-Monoline-Script





If there is a problem, question, or anything about my fonts, please sent an email to

mlkwsn999@gmail.com




Thanks,

MLKWSN Studios